//Construct maps

global path = "**INSERT DIR NAME**"

local map_path = "$path/data/gis/neighborhood_map_shp.dta"

//Distance to Midtown
import delimited "$path/data/travel_times.csv", clear
keep if destination_id==97
keep origin_id time_pre time_post
ren origin_id neighborhood_no
ren time_pre distance_midtown
ren time_post distance_midtown_post
tempfile distance_midtown
save `distance_midtown'

import delimited "$path/data/neighborhood_data.csv", clear
merge 1:1 neighborhood_no using `distance_midtown', nogen
merge 1:1 neighborhood_code using `estimated_parameters', nogen
merge 1:1 neighborhood_code using "$path/data/gis/neighborhood_IDs.dta", nogen

gen log_density_workers = log(nb_workers_pre/area)
gen log_density_jobs = log(nb_jobs_pre/area)

colorpalette #fafa6e #2a4858, ipolate(10, HCL power(1.5)) nograph
spmap price_floorspace using "`map_path'" , id(_ID) clmethod(custom) clbreaks(0(150)1500) ocolor(black ..) fcolor(`r(p)') osize(0.04 ..) ndocolor(black ..) ndfcolor(gs10 ..) ndsize(0.04 ..) ndlabel("No data") legend(pos(11) size(*2)) legstyle(2) title("Price of floorspace", size(vlarge)) 

colorpalette #fafa6e #2a4858, ipolate(9, HCL power(1.5)) nograph
spmap log_density_workers using "`map_path'" , id(_ID) clmethod(custom) clbreaks(6(.5)10.5) ocolor(black ..) fcolor(`r(p)') osize(0.04 ..) ndocolor(black ..) ndfcolor(gs10 ..) ndsize(0.04 ..) ndlabel("No data") legend(pos(11) size(*2)) legstyle(2) title("(log) Density of workers", size(vlarge)) 

colorpalette #fafa6e #2a4858, ipolate(14, HCL power(1.5)) nograph
spmap log_density_jobs using "`map_path'" , id(_ID) clmethod(custom) clbreaks(5.5(.5)12.5) ocolor(black ..) fcolor(`r(p)') osize(0.04 ..) ndocolor(black ..) ndfcolor(gs10 ..) ndsize(0.04 ..) ndlabel("No data") legend(pos(11) size(*2)) legstyle(2) title("(log) Density of jobs", size(vlarge)) 

colorpalette Gold Crimson Black, ipolate(10, HCL power(1.5)) nograph
spmap distance_midtown using "`map_path'" , id(_ID) clmethod(custom) clbreaks(0(5)50) ocolor(black ..) fcolor(`r(p)') osize(0.04 ..) ndocolor(black ..) ndfcolor(gs10 ..) ndsize(0.04 ..) ndlabel("No data") legend(pos(11) size(*2)) legstyle(2) title("Distance to Midtown (minutes)", size(vlarge)) 

colorpalette Gold Crimson Black, ipolate(10, HCL power(1.5)) nograph
spmap distance_midtown_post using "`map_path'" , id(_ID) clmethod(custom) clbreaks(0(5)50) ocolor(black ..) fcolor(`r(p)') osize(0.04 ..) ndocolor(black ..) ndfcolor(gs10 ..) ndsize(0.04 ..) ndlabel("No data") legend(pos(11) size(*2)) legstyle(2) title("Distance to Midtown (minutes)", size(vlarge)) 
